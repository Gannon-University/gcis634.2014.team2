package pOne;

public class iconst {
	public static void call(String command)
	{
		int constant = Integer.parseInt(command.substring(command.indexOf("_")+1,command.length()));
		System.out.println("Store constant");
		data.store(constant);
		
	}
}
