package pOne;

public class icmpeq {
	public static void call(String command, commands commandFeed)
	{
		int index = Integer.parseInt(command.substring(command.indexOf("q")+2,command.length()));
		
		if(data.retrieve()==data.retrieve())
		{
			System.out.println("If clause met");
			while(commandFeed.nextIndex()!=index)
			{
				commandFeed.next();
				System.out.println("Passing through");
			}
		}
		else
		{
			System.out.println("If clause not met");
		}
	}
}
