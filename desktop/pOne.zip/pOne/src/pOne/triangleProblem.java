package pOne;

public class triangleProblem 
{
	public int triangleType(int a, int b, int c)
	{
		if (a == b || a == c)
		{
			if (b==c)
			{
			return 1;
			}
			else
			{
			return 2;
			}
		}
		else if (b==c)
		{
			return 2;
		}
		else
		{
			return 3;
		}
	}
}
