package pOne;

import java.io.IOException;

public class main 
{
	public static void main(String Args[]) throws IOException
	{
		processor runner = new processor("data.txt");
		runner.executeCommands();
	}
}
