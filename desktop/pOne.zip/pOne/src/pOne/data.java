package pOne;

import java.util.Stack;

public class data 
{
	static Stack<Integer> dataStack = new Stack<Integer>();
	public static void store(int value)
	{
		dataStack.push(value);
	}
	public static int retrieve()
	{
		if (!dataStack.isEmpty())
			{
			return dataStack.pop();
			}
		else
			{
			return -1;
			}
	}

}
