package pOne;

import java.io.IOException;

public class processor
{
	commands commandFeed;
	int a =2 , b = 2, c = 2; //define variables
	public processor(String filepath) throws IOException
	{
		commandFeed = new commands(filepath);
	}
	public void executeCommands()
	{
		while(!commandFeed.isEmpty()) //While there are still commands in the queue, execute them
		{
			if (executeNext()) // Continue executing commands until we return true
				{
				break;
				}
		}
	}
	public boolean executeNext()
	{
		String command = new String();
		command = commandFeed.next();
		
		if(command.contains("iload"))
		{
			int value=0;
			int index = Integer.parseInt(command.substring(command.indexOf("_")+1,command.indexOf("_")+2));
			switch(index)
			{
			case 1: value=a; break;
			case 2: value=b; break;
			case 3: value=c; break;
			}
			iload.call(value); // Need to streamline this, passes the proper value based on the postscript of the command
		}
		else if(command.contains("if_icmpeq"))
		{
			icmpeq.call(command,commandFeed);
		}
		else if(command.contains("if_icmpne"))
		{
			icmpne.call(command,commandFeed);
		}
		else if(command.contains("iconst"))
		{
			iconst.call(command);
		}
		else if(command.contains("ireturn"))
		{
			ireturn.call();
			return true; //return true indicates we have hit a return, and should break out of the process stream
		}
		return false;
	}



}