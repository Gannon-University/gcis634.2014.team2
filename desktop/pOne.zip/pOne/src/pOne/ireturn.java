package pOne;

public class ireturn {
	public static int call()
	{
		System.out.println("Return");
		return data.retrieve();
	}
}
