package pOne;

public class icmpne {
	public static void call(String command, commands commandFeed)
	{
		int index = Integer.parseInt(command.substring(command.indexOf("ne")+3,command.length()));
		
		if(data.retrieve()!=data.retrieve())
		{
			System.out.println("If clause met 2");
			while(commandFeed.nextIndex()!=index)
			{
				commandFeed.next();
				System.out.println("Passing through 2");
			}
		}
		else
		{
			System.out.println("If clause not met 2");
		}
	}
}
