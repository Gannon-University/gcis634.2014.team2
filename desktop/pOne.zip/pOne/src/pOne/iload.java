package pOne;

public class iload {
	public static void call( int value)
	{
		System.out.println("Storing data");
		data.store(value);
	}
}
